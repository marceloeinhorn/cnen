from django.db import models
# Create your models here.
class Candidato (models.Model):
    candidato_cod = models.AutoField(primary_key=True)
    candidato_name = models.CharField(max_length=100)
    candidato_dtnasc = models.DateField
    candidato_CPF = models.IntegerField
    candidato_email = models.EmailField(unique='True',max_length=254)
    candidato_celular = models.IntegerField
    candidato_curriculo = models.FileField
    candidato_mensagem = models.TextField(max_length=200)

    def __str__(self):
        return self.candidato_name