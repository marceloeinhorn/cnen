# Create your views here.
from django.contrib.auth import authenticate, login, logout      # Visualização de Autorização e Controle de Acesso
from django.contrib.auth.decorators import login_required        
from django.contrib.auth.models import Group, Permission         # Controle de Usuários e Definição de Niveis
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader
from .models import Candidato

# Autenticação de Usuários
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('jws_home.html')
        else:
            return render(request, 'login.html', {'error': 'Credenciais inválidas'})
    return render(request, 'login.html')
def logout_view(request):
    logout(request)
    return redirect('login')

# Visualização de Autorização e Controle de Acesso
def dashboard_view(request):
    return render(request, 'dashboard.html')
@login_required
def create_user_groups():    
    editor_group, created = Group.objects.get_or_create(name='Editor')
    edit_permission = Permission.objects.get(codename='change_modelname')
    editor_group.permissions.add(edit_permission)

#Páginas Estáticas (não precisa)
#def jws_home(request):
    #return HttpResponse("<h1>Bem-vindo à Nossa Empresa!</h1>")
#def jws_contato(request):
    #return HttpResponse("<h1>Contacto</h1>")
#def jws_curriculo(request):
    #return HttpResponse("<h1>Currículo</h1>")

#Página Dinâmica
def jwsapp(request):
  template = loader.get_template('jws_home.html')
  return HttpResponse(template.render())
def jws_contato(request):
  template = loader.get_template('jws_contato.html')
  return HttpResponse(template.render())
def jws_curriculo(request):
  template = loader.get_template('jws_curriculo.html')
  return HttpResponse(template.render())

#Dados Form
def adicionar_candidato(request):
    if request.method == 'POST':
        Candidato.nome = request.POST['nome']
        Candidato.dtnasc = request.POST['dtnasc']
        Candidato.CPF = request.POST['CPF']
        Candidato.email = request.POST['e-mail']
        Candidato.celular = request.POST['celular']
        Candidato.curriculo = request.POST['currículo']
        Candidato.mensagem = request.POST['mensagem']
        Candidato.objects.create(candidato_nome='nome', 
                                 candidato_dtnasc='dtnasc', 
                                 candidato_CPF='CPF',
                                 candidato_email='e-mail',
                                 candidato_celular='celular',
                                 candidato_curriculo='curriculo',
                                 candidato_mensagem='mensagem')
        return redirect(adicionar_candidato)
    return render(request, 'jws_curriculo.html')

