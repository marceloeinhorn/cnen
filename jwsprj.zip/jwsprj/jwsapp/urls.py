#Arquivo tem que ser criado (dentro do app)
from django.urls import path
from . import views
urlpatterns = [
    path('jwsapp',views.jwsapp,name='jws_home'),                #Nome e Nome da View= App
    path('jws_contato',views.jws_contato,name='jws_contato'),
    path('jws_curriculo',views.jws_curriculo,name='jws_curriculo'),
    path('login',views.login_view,name='login'),
    path('logout',views.logout_view,name='logout'),
    path('dashboard',views.dashboard_view,name='dashboard'),
    path('edit',views.create_user_groups,name='edit'),
              ]
